package utils;

/**
 * createAt Dec 18, 2020
 *
 * @author Đỗ Tuấn Anh <daclip26@gmail.com>
 */
public enum PopupType {
    ADD,
    EDIT
}
